# 🎯 Dart - The Full Course

Master the [fundamantals of Dart](https://fireship.io/courses/dart/) before jumping into Flutter. 

Gert started with [Dart in 100 Seconds](https://youtu.be/NrO0CJCbYLA)

This repo is a refrence for the videos in the course.